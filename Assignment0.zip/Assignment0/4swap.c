#include<stdio.h>
void main(){
	int a=20;
	int b=30;
	int temp =a;
	a=b;
	b=temp;
	printf("The value of a and b: %d %d",a,b);
	
	
}
#include<stdio.h>
void main(){
	int r=4;
	int area=3.14*r*r;
	printf("Area of circal is :%d",area);
	
}
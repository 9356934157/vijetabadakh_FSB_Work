#include<stdio.h>
void main(){
	int a =130;
	int min = a%60;
	int hr =a/60;
	printf("The remaining min are :%d\n",min);
	printf("The remaining hr are :%d\n",hr);
	
	
	
}
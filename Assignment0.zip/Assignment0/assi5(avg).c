#include<stdio.h>
void main(){
	int a,b,c,d,e;
	a=5;
	b=10;
	c=6;
	d=8;
	e=9;
	int avg=(a+b+c+d+e)/5;
	printf("average of nubers :%d",avg);
	
}
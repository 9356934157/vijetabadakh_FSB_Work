#include<stdio.h>
void main(){
	int a=4;
	int square = a*a;
	int cude = a*a*a;
	printf("The Square is :%d\n",square);
	printf("The Cude is :%d",cude);
}
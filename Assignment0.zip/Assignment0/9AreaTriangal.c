#include<stdio.h>
void main(){
	int h=12;
	int b=14;
	int area =0.5*h*b;
	printf("Area of Triangle is :%d",area);
}
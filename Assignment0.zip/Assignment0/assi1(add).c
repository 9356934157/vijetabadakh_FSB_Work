#include<stdio.h>
void main(){
	int a=10;
	int b=20;
	int c=a+b;
	printf("Addition of a and b is :%d",c);
}
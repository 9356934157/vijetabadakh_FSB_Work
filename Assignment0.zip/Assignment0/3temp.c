#include<stdio.h>
void main(){
	int c=23;
	int f=((c*9/5)+32);
	printf("The temp in Fahrenheit are :%d",f);
}
#include<stdio.h>
void main(){
	int math =56;
	int phy =60;
	int chem =87;
	int marathi =90;
	int hindi =80;
	float total =(math+phy+chem+marathi+hindi);
	float percentage =(total/500)*100;
	printf("The toatl marks :%f\n",total);
	printf("The Percentage is :%f",percentage);
	
}
#include<stdio.h>
void main(){
	int r=12;
	int b=8;
	int pri=(2*(r+b));
	printf("The primeter of rectangal is:%d",pri);
}